<?php  include("menu.php") ?>
<?php
include("dbconnect.php");
$idcliente    = $_POST["idcliente"];
$nombrecli  = $_POST["nombrecli"];
$apellidocli  = $_POST["apellidocli"];
$usuariocli   = $_POST["usuariocli"];
$contraseñacli  = $_POST["contraseñacli"];
$direccioncli = $_POST["direccioncli"];
$telefonocli  = $_POST["telefonocli"];	  	
			
			//echo " codigo:", "$codigo", "nombre", "$nombrepro", "precio ", "$precio", "categoria", "$categoria", "cantidad", "$cantidad"		
  	

	$modificar = "UPDATE Clientes SET nombrecli = '$nombrecli', apellidocli='$apellidocli', usuariocli='$usuariocli', contraseñacli='$contraseñacli', direccioncli='$direccioncli', telefonocli='$telefonocli' WHERE idcliente='$idcliente'";
	
	$res = mysqli_query($link, $modificar);
	echo ($res);

	if(!$res)
 		echo ("No se ha modificado correctamente".mysql_errno());
	else
 		 //echo "Modificacion exitosa!";
 		 print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('datos guardados con exito');
					window.location=\"buscarmodificar.php#.reset()\";
					</script>";

?>