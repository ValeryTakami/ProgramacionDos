<!DOCTYPE html>
<html>
<head>
<title>Sistema de busqueda</title>
<?php  include("menu.php") ?>
</head>

 <body >

<?php	 
 $Id=$_POST['codigos'];
   //echo 'codigo resivido', $codigo;
   
   $servername = "localhost";
   $database = "frute";
   $username = "root";
   $password = "";
   // Create connection
   $link = mysqli_connect($servername, $username, $password);
   mysqli_select_db($link, $database);
  //$conn = mysqli_connect($servername, $username, $password, $database);
   // Check connection
   if (!$link) {
   	die("Connection failed: " . mysqli_connect_error());
	}
   //echo $id;
  	//require("dbconnect.php");
  	
   $sql = mysqli_query($link, "SELECT * FROM usuarios WHERE Id=$Id");
   if (mysqli_data_seek ($sql, 0)){
   	$result= mysqli_fetch_array($sql);
   	//echo 'si entra en la consulta';
   
	}		
 ?>
 
 <header>
       
 </header>
      

     
    <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
    <!--- objeto formulario -->
    <form id="muestra" name="muestra" method="post" action="">
    <div class="formulario" align="center">
  
           <li>
             <h2>Datos del usuario</h2>
           </li>
           <li>
             <label for="<Id">Id:</label>
              
              <input type="text" name="Id" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['Id']; ?>"/>
               
                            </li>
              <li>
              <label for="username">Nombre usuario:</label>
              
              <input type="text" name="username" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['username']; ?>"/>
               <label for="password">contraseña:</label>
            <input type="text" name="password" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['password']; ?>" /> 
              </li>
              
           <li>
              <label for="rol_id">Rol:</label>
              <input type="text" name="rol_id" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['rol_id']; ?>">
              
           </li>
        
              
		
                
                                <li>
                               
                                <button class="submit" href="buscaradm.php" type="submit">Salir</button>
                                    
                                   
                                </li>
                            </ul>
                         </div>
   </form>
       			  
                  <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
                  
                  
                <div id="footer">         
                  
		</div>   
                       
            </body>

</html>
