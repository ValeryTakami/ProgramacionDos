
<?php  include("menu.php") ?>
      <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
      <!--aqui ba el cofigo de la pagina -->
      
   

<br>
<br>
<?php
 include("dbconnect.php");
 $codigo=$_POST['codigos'];
// echo ($codigo);

  	
  	

	$borrar = "DELETE FROM productos WHERE codigo = '$codigo'";
	$res = mysqli_query($link, $borrar);
	//echo ($res);

	if(!$res)
 		echo ("No se ha realizado correctamente".mysql_errno());
	else
 		 print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('Baja realizada correctamente');
					window.location=\"baja.php#.reset()\";
					</script>";

?>


