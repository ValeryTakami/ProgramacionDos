<?php
//echo "hola";
include("dbconnect.php"); 

 

			$Id  = $_POST["Id"];
			$username = $_POST["username"];
			$password  = $_POST["password"];
			$rol_id = $_POST["rol_id"];
						
			
//echo "codigo: ", "$idadmin", "nombre", "$nombreadm", "precio", "$apellidoadm", "categoria", "$nomusuario", "cantidad", "$contraseña";		
	//echo "SELECT * FROM Administrador WHERE codigo=$idadmin";
	$result = mysqli_query($link, "SELECT * FROM usuarios WHERE Id= $Id");
	
	if (mysqli_data_seek ($result, 0)){
	//echo "ya existo";
		$extraido= mysqli_fetch_array($result);
		//echo "ya existe ";
		print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('El codigo ya existe o fue registrado con anterioridad favor de verificar');
					window.location='javascript:window.history.back()';
					</script>";
		
		
		}
	else{
		//echo 'ya esta';
		
		$sql = "INSERT INTO usuarios (Id, username, password, rol_id) VALUES ('$Id', '$username', '$password', '$rol_id')";
		
	//echo "$sql";
		if (mysqli_query($link, $sql)) {
      			//echo "dato guardado con exito";
      			print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('datos guardados con exito');
					window.location=\"admalta.php#.reset()\";
					</script>";
		} else {
    			echo "Error estoy en error: " . $sql . "<br>" . mysqli_error($link);
		}
	    	
	   }
	
//mysqli_free_result($result);

//mysqli_close($link);

?> 		
