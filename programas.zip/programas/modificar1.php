<!DOCTYPE html>
<html>
<head>
<title>Sistema de busqueda</title>
<?php  include("menu.php") ?>
</head>

 <body >

<?php	 
 $codigo=$_POST['codigos'];
   //echo 'codigo resivido', $codigo;
   
   $servername = "localhost";
   $database = "frute";
   $username = "root";
   $password = "";
   // Create connection
   $link = mysqli_connect($servername, $username, $password);
   mysqli_select_db($link, $database);
  //$conn = mysqli_connect($servername, $username, $password, $database);
   // Check connection
   if (!$link) {
   	die("Connection failed: " . mysqli_connect_error());
	}
   //echo $id;
  	//require("dbconnect.php");
  	
   $sql = mysqli_query($link, "SELECT * FROM productos WHERE codigo=$codigo");
   if (mysqli_data_seek ($sql, 0)){
   	$result= mysqli_fetch_array($sql);
   	//echo 'si entra en la consulta';
   
	}						//echo $qry;
							//mysql_query("SET NAMES utf8");
							//	$res = mysql_query($qry)or die(mysql_error());
       						//$extraido = mysql_fetch_array($);
 ?>
 
 <header>
       
 </header>
      

     
    <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
    <!--- objeto formulario -->
    <form id="muestra" name="muestra" method="post" action="modificar2.php">
    <div class="formulario" align="center">
  
           <li>
             <h2>Datos del producto</h2>
           </li>
           <li>
             <label for="codigo">Codigo:</label>
              
              <input type="text" name="codigo" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['codigo']; ?>"/>
               
                            </li>
              <li>
              <label for="nompro">Nombre Producto:</label>
              
              <input type="text" name="nombrepro" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['nombrepro']; ?>"/>
               <label for="pre">precio:</label>
            <input type="text" name="precio" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['precio']; ?>" /> 
              </li>
              
           <li>
              <label for="cat">categoria</label>
              <input type="text" name="categoria" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['categoria']; ?>">
              <label for="cantidad">cantidad:</label>
              <input type="text" name="cantidad" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['cantidad']; ?>">
             
           </li>
        
              
		
                
                                <li>
                               
                                    <button name="Enviar" class="submit" type="submit">Modificar </button>
                                    
                                   
                                </li>
                            </ul>
                         </div>
   </form>
       			  
                  <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
                  
                  
                <div id="footer">         
                  
		</div>   
                       
            </body>

</html>
