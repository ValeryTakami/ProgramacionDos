<!DOCTYPE html>

<body>
      
    <?php  include("menu.php") ?>
      <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
      <!--aqui ba el cofigo de la pagina -->
      
   <form id="productos" name="productos" method="post" action="bajasadm.php">
   <div class="formulario" align="center">
  <table width="80%" border="0">
  <h2>Eliminar producto</h2>
    <tr>
      <!-- <td colspan="2"><img src="../pagina/img/Header.png" width="989" height="172" /></td> -->
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td width="50%" align="right">Id usuarios
        <input type="text" id="codigos" name="codigos" value=""/></td>
      <td width="30%"><input type="submit" name="baja" id="Eliminar" value="Eliminar" /></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><h2><a href="javascript:window.history.back();">Regresar</a></h2></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
      <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
             
      <!-- <object  type="text/html"   data="inicio.html"   style="width: 95%; height:500px;  margin-left:200px"> -->
   <div id="footer"> </div>
                        
 </body>

</html>
</html>
