?php  include("menu.php") ?>
<?php
include("dbconnect.php");
$Id   = $_POST["Id"];
$username = $_POST["username"];
$password  = $_POST["password"];
$rol_id  = $_POST["rol_id"];
	
			
			//echo " codigo:", "$codigo", "nombre", "$nombrepro", "precio ", "$precio", "categoria", "$categoria", "cantidad", "$cantidad"		
  	

	$modificar = "UPDATE usuarios SET username = '$username', password='$password', rol_id='$rol_id ' WHERE Id='$Id'";
	
	$res = mysqli_query($link, $modificar);
	echo ($res);

	if(!$res)
 		echo ("No se ha modificado correctamente".mysql_errno());
	else
 		 //echo "Modificacion exitosa!";
 		 print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('datos guardados con exito');
					window.location=\"buscarmodificar.php#.reset()\";
					</script>";

?>