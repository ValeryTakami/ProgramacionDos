<!DOCTYPE html>
<head>

<?php  include("menu.php") 
?> 

 <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
  <!--- objeto formulario -->
   <form name= "productos" id="productos" action="altaCli.php" method="post">
      <div class="formulario" align="center">
  
           <li>
             <h2>Altas de clientes</h2>
           </li>
           <li>
              <label for="idcliente">Id cliente:</label>
                <input name="idcliente" type="text" required id="idcliente" placeholder="Escribe el id" />
                            </li>
              <li>
              <label for="nombrecli"> Nombre cliente:</label>
                <input name="nombrecli" type="text" required id="nombrecli" placeholder="nombre" />                 
                <label for="apellidocli">Apellido cliente</label>
                 <input name="apellidocli" type="text" required id="apellidocli" placeholder="Apellido"/> 
              </li>
              
           <li>
               <label for="usuariocli">Usuario:</label>
                 <input name="usuariocli" type="text" required id="usuariocli" placeholder="Usuario"/>
   		      <label for="contraseñacli">contraseña:</label>
                 <input name="contraseñacli" type="tel"  id="contraseñacli" placeholder="contraseña" />
             
           </li>
           <li>
              <label for="direc">Direccion del cliente:</label>
                <input name="direccioncli" type="text" required id="direccioncli" placeholder="nombre" />                 
                <label for="tel">Telefono cliente</label>
                 <input name="telefonocli" type="text" required id="telefonocli" placeholder="telefono"/> 
              </li>
        
              
		
                
                                <li>
                                
                                    <button name="Enviar" class="submit" type="submit">Guardar </button>
                			 <button class="submit" type="reset"> Limpiar</button>
                                    
                                   
                                </li>
                            </ul>
                         </div>
   </form>
  	  
      <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
