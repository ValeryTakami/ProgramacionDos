<?php
//echo "hola";
$servername = "localhost";
   $database = "frute";
   $username = "root";
   $password = "";
   // Create connection
   $link = mysqli_connect($servername, $username, $password);
   mysqli_select_db($link, $database);
  //$conn = mysqli_connect($servername, $username, $password, $database);
   // Check connection
   if (!$link) {
   	die("Connection failed: " . mysqli_connect_error());
	}
			$codigo  = $_POST["codigo"];
			$nombrepro = $_POST["nombrepro"];
			$precio  = $_POST["precio"];
			$categoria  = $_POST["categoria"];
						
			
//echo "codigo: ", "$idadmin", "nombre", "$nombreadm", "precio", "$apellidoadm", "categoria", "$nomusuario", "cantidad", "$contraseña";		
	//echo "SELECT * FROM Administrador WHERE codigo=$idadmin";
	$result = mysqli_query($link, "SELECT * FROM productos WHERE codigo= $codigo");
	
	if (mysqli_data_seek ($result, 0)){
	//echo "ya existo";
		$extraido= mysqli_fetch_array($result);
		//echo "ya existe ";
		print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('El codigo ya existe o fue registrado con anterioridad favor de verificar');
					window.location='javascript:window.history.back()';
					</script>";
		}
	else{
		//echo 'ya esta';
		
		$sql = "INSERT INTO productos (codigo, nombrepro, precio, categoria) VALUES ('$codigo', '$nombrepro', '$precio', '$categoria')";
		
	//echo "$sql";
		if (mysqli_query($link, $sql)) {
      			//echo "dato guardado con exito";
      			print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('datos guardados con exito');
					window.location=\"admalta.php#.reset()\";
					</script>";
		} else {
    			echo "Error estoy en error: " . $sql . "<br>" . mysqli_error($link);
		}
	    	
	   }
	
//mysqli_free_result($result);

//mysqli_close($link);

?> 		
