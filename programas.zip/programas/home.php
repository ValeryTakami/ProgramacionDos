<!DOCTYPE html>
<html lang="es">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
</head>
<!--<body BACKGROUND="img/ropa1.jpg">-->
<body>
<center><h1>  BIENVENIDOS  </h1></center>
<?php
include('menu.php');
?>
</body>
</html>