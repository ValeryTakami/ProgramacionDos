<!DOCTYPE html>
<head>

<?php  include("menu.php") 
?> 

 <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
  <!--- objeto formulario -->
   <form name= "productos" id="productos" action="alta_PHP.php" method="post">
      <div class="formulario" align="center">
  
           <li>
             <h2>Altas de producto</h2>
           </li>
           <li>
              <label for="codigo">Codigo Producto:</label>
                <input name="codigo" type="text" required id="codigo" placeholder="Escribe el codigo" requiered/>
                            </li>
              <li>
              <label for="nombrepro"> Nombre del producto:</label>
                <input name="nombrepro" type="nombrepro" required id="nombrepro" placeholder="nombre" />                 
                <label for="precio">Precio:</label>
                 <input name="precio" type="text" required id="precio" placeholder="precio"/> 
              </li>
              
           <li>
               <label for="categoria">Categoria:</label>
                 <input name="precio" type="text" required id="precio" placeholder="FRUTA/VERDURA"/>
   		      
             
</li> 
                                    <button name="Enviar" class="submit" type="submit">Guardar </button>
                			 <button class="submit" type="reset"> Limpiar</button>
                                    
                                   
                                </li>
                            </ul>
                         </div>
   </form>
  	  
      <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
             
     
