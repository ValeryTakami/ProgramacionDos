<!DOCTYPE html>
<head>

<?php  include("menu.php") 
?> 

 <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
  <!--- objeto formulario -->
   <form name= "productos" id="productos" action="altaAdm.php" method="post">
      <div class="formulario" align="center">
  
           <li>
             <h2>Altas de usuarios</h2>
           </li>
           <li>
              <label for="Id">Id usuario:</label>
                <input name="Id" type="text" required id="Id" placeholder="Escribe el id" requiered/>
                            </li>
              <li>
              <label for="username"> Nombre usuario</label>
                <input name="username" type="text" required id="username" placeholder="nombre" />                 
                <label for="password">Contraseña usuario:</label>
                 <input name="password" type="text" required id="password" placeholder="Contraseña"/> 
              </li>
              
           <li>
               <label for="rol_id">ROL:</label>
                 <input name="rol_id" type="text" required id="rol_id" placeholder="rol_id"/>
   		      
           </li>
        
              
		
                
                                <li>
                                
                                    <button name="Enviar" class="submit" type="submit">Guardar </button>
                			 <button class="submit" type="reset"> Limpiar</button>
                                    
                                   
                                </li>
                            </ul>
                         </div>
   </form>
  	  
      <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
