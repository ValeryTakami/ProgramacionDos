<?php
include("menu2.php")
?>
<html lang="es">
  <head>
<div class="product-big-title-area">
<div class="formulario" align="center">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>Gracias Por Su Preferencia</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
            
                <div class="col-md-12">
                    <div class="product-content-right">
                        <div class="woocommerce">
                        <div class="formulario" align="center">

                            <h2>Su Compra Fué Realizada con Éxito</h2>
                            <div class="table-responsive col-xs-12">
                                    <table cellspacing="0" class="shop_table cart">
                                        <thead>
                                            <tr>
            
                                            <td>
    <form id="form1" method="post" action="orden.php">
        <input type="submit" name="button" id="button" value="Regresar" class="btn btn-success"
</head>
</html>                                       