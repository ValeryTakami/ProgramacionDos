<!DOCTYPE html>
<html>
<head>
<title>Sistema de busqueda</title>
<?php  include("menu.php") ?>
</head>

 <body >

<?php	 
 $idcliente=$_POST['codigos'];
   //echo 'codigo resivido', $codigo;
   
   $servername = "localhost";
   $database = "frute";
   $username = "root";
   $password = "";
   // Create connection
   $link = mysqli_connect($servername, $username, $password);
   mysqli_select_db($link, $database);
  //$conn = mysqli_connect($servername, $username, $password, $database);
   // Check connection
   if (!$link) {
   	die("Connection failed: " . mysqli_connect_error());
	}
   //echo $id;
  	//require("dbconnect.php");
  	
   $sql = mysqli_query($link, "SELECT * FROM Clientes WHERE idcliente=$idcliente");
   if (mysqli_data_seek ($sql, 0)){
   	$result= mysqli_fetch_array($sql);
   	//echo 'si entra en la consulta';
   
	}						//echo $qry;
							//mysql_query("SET NAMES utf8");
							//	$res = mysql_query($qry)or die(mysql_error());
       						//$extraido = mysql_fetch_array($);
					
 
					
 ?>
     <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
    <!--- objeto formulario -->
    <form id="muestra" name="muestra" method="post" action="modificar2cli.php">
    <div class="formulario" align="center">
  
           <li>
             <h2>Datos del cliente</h2>
           </li>
           <li>
             <label for="idcliente">Id Cliente:</label>
              
              <input type="text" name="idcliente" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['idcliente']; ?>"/>
               
                            </li>
              <li>
              <label for="nombrecli">Nombre Cliente:</label>              
              <input type="text" name="nombrecli" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['nombrecli']; ?>"/>
               <label for="ape">Apellido Cliente:</label>
            <input type="text" name="apellidocli" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['apellidocli']; ?>" /> 
              </li>
              
           <li>
              <label for="usu">nombre de usuario</label>
              <input type="text" name="usuariocli" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['usuariocli']; ?>">
              <label for="con">contraseña:</label>
              <input type="text" name="contraseñacli" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['contraseñacli']; ?>">
             
           </li>
           
           <li>
              <label for="direc">Direccion del cliente</label>
              <input type="text" name="direccioncli" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['direccioncli']; ?>">
              <label for="tel">Telefono cliente:</label>
              <input type="text" name="telefonocli" style="color: #0000FF; font-size: 10pt" value="<?php echo $result['telefonocli']; ?>">
             
           </li>
                
                                <li>
                               
                                <button name="Enviar" class="submit" type="submit">Modificar </button>
                                    
                                   
                                </li>
                            </ul>
                         </div>
   </form>
       			  
                  <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
                  
                  
                <div id="footer">         
                  
		</div>   
                       
            </body>

</html>
