<?php
//echo 'holas';
$servername = "localhost";
$database = "frute";
$username = "root";
$password = "";
// Create connection
$link = mysqli_connect($servername, $username, $password);
mysqli_select_db($link, $database);

if (!$link) {
      die("Connection failed: " . mysqli_connect_error());
}
 
else{
	//echo "Connected successfully";
	}



?>
