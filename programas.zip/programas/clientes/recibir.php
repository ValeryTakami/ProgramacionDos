<link rel="stylesheet" href="style.css">
<?php
	echo "<h1>Codigo de producto: " .$_GET['codigo']."</h1>";
	echo "<br>";
	echo "<h1>Producto: " .$_GET['nombrepro']."</h1>";
?>