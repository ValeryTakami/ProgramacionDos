<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "frute");
if(isset($_POST["add_to_cart"]))
{
if(isset($_SESSION["shopping_cart"]))
{
$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
if(!in_array($_GET["codigo"], $item_array_id))
{
$count = count($_SESSION["shopping_cart"]);
$item_array = array(
'item_codigo' => $_GET["codigo"],
'item_nombrepro' => $_POST["hidden_nombrepro"],
'item_precio' => $_POST["hidden_precio"],
'item_quantity' => $_POST["quantity"]
);
$_SESSION["shopping_cart"][$count] = $item_array;
}
else
{
echo '<script>alert("El producto ya se encuentra agregado")</script>';

}
}
else
{
$item_array = array(
'item_codigo' => $_GET["codigo"],
'item_nombrepro' => $_POST["hidden_nombrepro"],
'item_precio' => $_POST["hidden_precio"],
'item_quantity' => $_POST["quantity"]
);
$_SESSION["shopping_cart"][0] = $item_array;
}
}
if(isset($_GET["action"]))
{
if($_GET["action"] == "delete")
{
foreach($_SESSION["shopping_cart"] as $keys => $values)
{
if($values["item_codigo"] == $_GET["codigo"])
{
unset($_SESSION["shopping_cart"][$keys]);
echo '<script>alert("Producto eliminado")</script>';
echo '<script>window.location="in.php"</script>';
}
}
}
}
?>
<!DOCTYPE html>
<html>
<?php  include("menu2.php") ?>
<head>
<title> Carro de Compra </title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> 
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container" style="width:800px;">
<div style="clear:both"></div>
<h3>Detalle de la orden</h3>
<div class="table-responsive">
<table class="table table-bordered">
<tr>
<th width="40%">Nombre</th>
<th width="10%" class='text-center'>Cantidad</th>
<th width="20%" class='text-right'>Precio</th>
<th width="15%" class='text-right'>Total</th>
<th width="5%"></th>
</tr>
<?php
if(!empty($_SESSION["shopping_cart"]))
{
$total = 0;
foreach($_SESSION["shopping_cart"] as $keys => $values)
{
?>
<tr>
<td><?php echo $values["item_nombrepro"]; ?></td>
<td class='text-center'><?php echo $values["item_quantity"]; ?></td>
<td class='text-right'>$ <?php echo $values["item_precio"]; ?></td>
<td class='text-right'>$ <?php echo number_format($values["item_quantity"] * $values["item_precio"], 2); ?></td>
<td><a href="in.php?action=delete&id=<?php echo $values["item_codigo"]; ?>"><span class="text-danger">Eliminar</span></a></td>
</tr>
<?php
$total = $total + ($values["item_quantity"] * $values["item_precio"]);
}
?>
<tr>
<td colspan="3" align="right">Total</td>
<td align="right">$ <?php echo number_format($total, 2); ?></td>
<td></td>
</tr>
<?php
}
?></table>
</div>
</div>
</body>
</html> 