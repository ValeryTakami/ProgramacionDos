<!DOCTYPE html>
<head>
<body>

<?php  include("menu2.php") 
?> 

 <!--xxxxxxxxxxxxxxxxxxxxxxxxx-->
  <!--- objeto formulario -->
   <form name= "productos" id="productos" action="" method="post">
      <div class="formulario" align="center">
      <li><h1>BIENVENIDO Administrador </h1></li>
             <li><h2 class="big-heading">Descubre nuestros beneficios</h2>
           </li>
           <li><div class="container-fluid">      
      	 <div class="row">
        <div class="col-lg-4 feature-box">
          <i class="icon fas fa-truck fa-4x"></i>
          <h3 class="feature-title">Entregas a Domicilio</h3>
          <p>Te llevamos tu pedido a la puerta de tu casa.</p>
        </div>
        <div class="col-lg-4 feature-box">
          <i class="icon fas fa-check-circle fa-4x"></i>
          <h3 class="feature-title">Entregas el mismo día</h3>
          <p>Haz tu pedido y recíbelo en minutos.</p>
        </div>
        <div class="col-lg-4 feature-box">
          <i class="icon fas fa-award fa-4x"></i>
          <h3 class="feature-title">Garantía de calidad</h3>
          <p>Si tu producto llego dañado, te lo cambiamos sin ningún costo.</p>
        </div>
        <div class="col-lg-4 feature-box">
          <i class="icon fas fa-tags fa-4x"></i>
          <h3 class="feature-title">Descuentos cada mes</h3>
          <p>¡Un nuevo cupón cada mes!</p>
        </div>
        <div class="col-lg-4 feature-box">
          <i class="icon fas fa-coins fa-4x"></i>
          <h3 class="feature-title">Cashback</h3>
          <p>¡Por cada compra que hagas, tú también ganas!</p>
        </div>
        <div class="col-lg-4 feature-box">
          <i class="icon fas fa-calendar-week fa-4x"></i>
          <h3 class="feature-title">Entregas en fines de semana</h3>
          <p>Para empezar la semana con todos tus ingredientes</p>
        </div>
      </div>
</section>


 

  <!-- Horarios -->

  <section class="white-section" id="horarios">

    <div class="horarios-column col-lg-12">
      <h2 class="section-heading">Entregas en el horario que necesites.</h2>
      <i class="icon fas fa-clock fa-4x"></i>
      <!-- Acordion -->
      <div class="accordion accordion-flush" id="accordionFlushExample">
        <div class="accordion-item">
          <h2 class="accordion-header" id="flush-headingOne">
            <h2>Horarios </h2>
          
              <table class="table table-borderless">
                <thead>
                  <tr>
                    <th scope="col">Lunes - Viernes</th>
                    <th scope="col">Sábado y Domingo</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>9:00 AM - 6:00 PM</td>
                    <td>9:00 AM - 4:00 PM</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header" id="flush-headingTwo">
            <h2>Entregas</h2>
          
              <table class="table table-borderless table-hover">
                <thead>
                  <tr>
                    <th scope="col">Lunes - Viernes</th>
                    <th scope="col">Pedir antes de</th>
                    <th scope="col">Sábado y Domingo</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>9:00 AM - 1:00 PM</td>
                    <td class="cierre">8:00 AM</td>
                    <td>9:00 AM - 1:00 PM</td>
                  </tr>
                  <tr>
                    <td>1:00 PM - 4:00 PM</td>
                    <td class="cierre">12:00 PM</td>
                    <td>1:00 PM - 4:00 PM</td>
                  </tr>
                  <tr>
                    <td>4:00 PM - 6:00 PM</td>
                    <td class="cierre">3:00 PM</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>

  
  </footer>

</body>

</html>
