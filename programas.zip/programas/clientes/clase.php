<?php
class DBControl {
	private $link;
	
	function __construct() 
	{ 
	$this->link = $this->conectarDB();
	}
	
	function conectarDB() 
	{
		$link= mysqli_connect("localhost","root","","frute");
		return $link;
	}
	
	function vaiquery($query) 
	{
		$resultado = mysqli_query($this->link,$query);
		while($fila=mysqli_fetch_assoc($resultado)) 
		{
			$obtener_resultado[] = $fila;
		}		
		if(!empty($obtener_resultado))
		{
		return $obtener_resultado;
		}
	}
	
	function nfilas($query) {
		$resultado  = mysqli_query($this->link,$query);
		$totalfilas = mysqli_num_rows($resultado);
		return $totalfilas;	
	}
}
?>