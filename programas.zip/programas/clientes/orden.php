<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "frute");
if(isset($_POST["add_to_cart"]))
{
if(isset($_SESSION["shopping_cart"]))
{
$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
if(!in_array($_GET["codigo"], $item_array_id))
{
$count = count($_SESSION["shopping_cart"]);
$item_array = array(
'item_codigo' => $_GET["codigo"],
'item_nombrepro' => $_POST["hidden_nombrepro"],
'item_precio' => $_POST["hidden_precio"],
'item_quantity' => $_POST["quantity"]
);
$_SESSION["shopping_cart"][$count] = $item_array;
}
else
{
echo '<script>alert("El producto ya se encuentra agregado")</script>';

}
}
else
{
$item_array = array(
'item_codigo' => $_GET["codigo"],
'item_nombrepro' => $_POST["hidden_nombrepro"],
'item_precio' => $_POST["hidden_precio"],
'item_quantity' => $_POST["quantity"]
);
$_SESSION["shopping_cart"][0] = $item_array;
}
}
if(isset($_GET["action"]))
{
if($_GET["action"] == "delete")
{
foreach($_SESSION["shopping_cart"] as $keys => $values)
{
if($values["item_codigo"] == $_GET["codigo"])
{
unset($_SESSION["shopping_cart"][$keys]);
echo '<script>alert("Producto eliminado")</script>';
echo '<script>window.location="in.php"</script>';
}
}
}
}
?>
<!DOCTYPE html>
<html>
<?php  include("menu2.php") ?>
<head>
<title> Carro de Compra </title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> 
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<form id="productos" name="productos" method="post" action="in.php">
<div class="container" style="width:800px;">
<h3 align="center">Carro de Compra </h3>
<?php
$query = "SELECT * FROM productos ORDER BY codigo ASC";
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
while($row = mysqli_fetch_array($result))
{
?>
<div class="col-md-4">
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>?action=add&id=<?php echo $row["codigo"]; ?>">
<div class="thumbnail">

<div class="caption">
<h4 class="text-info text-center">Codigo: <?php echo $row["codigo"]; ?></h4>
<h4 class="text-info text-center"><?php echo $row["nombrepro"]; ?></h4>
<h4 class="text-danger text-center">$ <?php echo $row["precio"]; ?></h4>
<input type="text" name="quantity" class="form-control" value="1" />
<p class='text-center'>
<input type="submit" name="add_to_cart" class="btn btn-success " value="Agregar al carro" /></p>

<input type="hidden" name="hidden_nombrepro" value="<?php echo $row["nombrepro"]; ?>" />
<input type="hidden" name="hidden_precio" value="<?php echo $row["precio"]; ?>" />
</div>
</div>
</form>
</div>
<?php
}
}
?>