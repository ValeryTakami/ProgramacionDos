<?php

    session_start();

    if(!isset($_SESSION['rol'])){
        header('location: login.php');
    }else{
        if($_SESSION['rol'] != 1){
            header('location: login.php');
        }
    }

    include("menu.php")
?>
<!DOCTYPE html>
<html lanf="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <div class="formulario" align="center">
        <title>ADMIN</title>
</head>
<body>
    <h1>BIENVENIDO Administrador </h1>

</body>


</html>
