<?php include "dbconnect.php";
?>
<!DOCTYPE html>
<head>
    <title>lista de productos</title>
</head>
<body>
    <section id="container">
        <h1><i class="fas fa-cube"></i>lista productos</h1>
        <a hr