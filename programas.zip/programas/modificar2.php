<?php  include("menu.php") ?>
<?php
include("dbconnect.php");
			$codigo  = $_POST["codigo"];
			$nombrepro  = $_POST["nombrepro"];
			$precio  = $_POST["precio"];
			$categoria  = $_POST["categoria"];
			$cantidad  = $_POST["cantidad"];  	
			
			//echo " codigo:", "$codigo", "nombre", "$nombrepro", "precio ", "$precio", "categoria", "$categoria", "cantidad", "$cantidad"		
  	

	$modificar = "UPDATE productos SET nombrepro = '$nombrepro', precio='$precio', categoria='$categoria', cantidad='$cantidad' WHERE codigo='$codigo'";
	
	$res = mysqli_query($link, $modificar);
	echo ($res);

	if(!$res)
 		echo ("No se ha modificado correctamente".mysql_errno());
	else
 		 //echo "Modificacion exitosa!";
 		 print "<SCRIPT LANGUAGE=\"JavaScript\">
					alert('datos guardados con exito');
					window.location=\"buscarmodificar.php#.reset()\";
					</script>";

?>
		
	
