from django.contrib import admin
from .models import Empresa, Programador

admin.site.register(Empresa)

admin.site.register(Programador)