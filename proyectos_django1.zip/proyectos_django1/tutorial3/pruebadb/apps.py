from django.apps import AppConfig


class PruebadbConfig(AppConfig):
    name = 'pruebadb'
