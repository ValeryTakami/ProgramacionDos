from django.apps import AppConfig


class HolaConfig(AppConfig):
    name = 'hola'
