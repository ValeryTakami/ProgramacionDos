# curso_django_youtube
## Todos los proyectos del curso de django en canal de youtube.

### Sólo busquen el proyecto por nombre, tienen el mismo nombre que en los videos de youtube.

### pd: es un directorio para TODOS los proyectos, tienen que descargar todo el directorio y después buscar el proyecto en específico.
